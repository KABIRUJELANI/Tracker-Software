/**
 * Payments.gs — Payment & Financial Analysis
 * Pending / received / completed tracking, overdue flagging, and a recurring
 * follow-up workflow that keeps nudging until an item is closed.
 */

var PAYMENT_STATUSES = ['Pending', 'Received', 'Completed'];

function listPayments(filters) {
  requirePermission_('payments', 'read');
  var today = new Date();
  var rows = applyFilters_(readAll_('Payments'), filters).map(function (p) {
    var overdue = p.status === 'Pending' && p.dueDate && new Date(p.dueDate) < today;
    return Object.assign({}, p, { overdue: overdue });
  });
  return rows;
}

function savePayment(record) {
  requirePermission_('payments', 'write');
  var user = getCurrentUser();
  if (record._row) {
    if (record.status === 'Received' && !record.receivedDate) record.receivedDate = new Date();
    updateRecord_('Payments', record._row, record);
    logAudit_('payment_updated', 'payments', record.id, record.status || '');
  } else {
    record.id = genId_('PAY');
    record.createdBy = user.email;
    record.createdAt = nowIso_();
    record.status = record.status || 'Pending';
    record.followUpCount = 0;
    appendRecord_('Payments', record);
    logAudit_('payment_created', 'payments', record.id, record.description || '');
  }
  return { ok: true, id: record.id };
}

/** Log a manual follow-up on an unresolved payment (module 4's "recurring follow-up workflow"). */
function logPaymentFollowUp(id, note) {
  requirePermission_('payments', 'write');
  var rows = readAll_('Payments');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Payment not found: ' + id);
  updateRecord_('Payments', row._row, { followUpCount: (Number(row.followUpCount) || 0) + 1, lastFollowUpAt: nowIso_() });
  logAudit_('payment_followup', 'payments', id, note || '');
  return true;
}

function getPaymentsSummary(filters) {
  requirePermission_('payments', 'read');
  var rows = listPayments(filters);
  var sum = function (arr) { return arr.reduce(function (a, b) { return a + (Number(b.amount) || 0); }, 0); };
  var pending = rows.filter(function (r) { return r.status === 'Pending'; });
  var received = rows.filter(function (r) { return r.status === 'Received'; });
  var completed = rows.filter(function (r) { return r.status === 'Completed'; });
  var overdue = rows.filter(function (r) { return r.overdue; });
  return {
    pendingCount: pending.length, pendingAmount: sum(pending),
    receivedCount: received.length, receivedAmount: sum(received),
    completedCount: completed.length, completedAmount: sum(completed),
    overdueCount: overdue.length, overdueAmount: sum(overdue)
  };
}

/** Scheduled scan: overdue-past-threshold payments get escalated to Finance/Management. */
function runPaymentsScan_() {
  var threshold = Number(getSetting('paymentOverdueDaysThreshold', 14));
  var today = new Date();
  readAll_('Payments').forEach(function (p) {
    if (p.status !== 'Pending' || !p.dueDate) return;
    var overdueDays = daysBetween_(new Date(p.dueDate), today);
    if (overdueDays >= threshold) {
      escalateIfNew_('payments', p.id, p.unit, 'Payment "' + p.description + '" (' + fmtCurrency_(p.amount) + ') overdue by ' + overdueDays + ' day(s).', overdueDays >= threshold * 2 ? 'High' : 'Medium');
    }
  });
}
