/**
 * Settings.gs
 * Config-driven thresholds & KPI targets, editable from the Admin module.
 * Backed by the "Settings" sheet (key/value). Nothing here is hardcoded elsewhere.
 */

function getAllSettings() {
  return readAll_('Settings');
}

function saveSetting(key, value) {
  requirePermission_('admin', 'write');
  var rows = readAll_('Settings');
  var existing = rows.filter(function (r) { return r.key === key; })[0];
  if (existing) {
    updateRecord_('Settings', existing._row, { key: key, value: value, updatedAt: nowIso_(), updatedBy: currentUserEmail_() });
  } else {
    appendRecord_('Settings', { key: key, value: value, updatedAt: nowIso_(), updatedBy: currentUserEmail_() });
  }
  invalidateCache_('settings');
  return getAllSettings();
}

/** Default thresholds seeded by SETUP.gs — see DEFAULT_SETTINGS in SETUP.gs. */
