/**
 * Dashboard.gs — Centralized Management Dashboard (module 3)
 * Single landing view combining outstanding tasks, completed activities,
 * pending actions, and key issues across all three units. Also serves the
 * Management & Executive Reporting view (module 5) with the same filters.
 */

function getDashboardData(filters) {
  requirePermission_('dashboard', 'read');
  var jobs = listJobs(filters);
  var payments = listPayments(filters);
  var incidents = applyFilters_(readAll_('Incidents'), filters);
  var contracts = applyFilters_(readAll_('Contracts'), filters);
  var pendingActions = getPendingActionsRegister(filters);
  var escalations = listEscalations(filters).slice(0, 15);
  var fileAnalysis = getFilePositionalAnalysis(filters);

  return {
    sections: getDashboardSections(),
    kpis: {
      openJobs: jobs.filter(function (j) { return j.status !== 'Completed'; }).length,
      completedJobs: jobs.filter(function (j) { return j.status === 'Completed'; }).length,
      untouchedJobs: jobs.filter(function (j) { return j.status === 'Untouched'; }).length,
      overdueJobs: jobs.filter(function (j) { return j.overdue; }).length,
      pendingPayments: payments.filter(function (p) { return p.status === 'Pending'; }).length,
      overduePayments: payments.filter(function (p) { return p.overdue; }).length,
      openIncidents: incidents.filter(function (i) { return i.status !== 'Resolved'; }).length,
      highSeverityIncidents: incidents.filter(function (i) { return i.severity === 'High' && i.status !== 'Resolved'; }).length,
      activeContracts: contracts.filter(function (c) { return c.stage !== 'closure'; }).length,
      filesStuck: fileAnalysis.filter(function (f) { return f.isStuck; }).length,
      pendingActionsCount: pendingActions.length,
      overduePendingActions: pendingActions.filter(function (a) { return a.overdue; }).length
    },
    paymentsSummary: getPaymentsSummary(filters),
    pendingActions: pendingActions.slice(0, 25),
    recentEscalations: escalations,
    recentIncidents: incidents.filter(function (i) { return i.status !== 'Resolved'; }).slice(0, 10),
    jobAgeing: getPendingJobsAnalysis(filters).ageingBuckets
  };
}

/** Distinct entry point for the CEO/Head-of-Contract executive view (module 5):
 *  same underlying data, framed as KPI + attention-flags rather than raw lists. */
function getExecutiveReport(filters) {
  requirePermission_('dashboard', 'read');
  var dash = getDashboardData(filters);
  var kpiAnalysis = getKpiAnalysis(filters && filters.unit);
  var attentionFlags = [];
  if (dash.kpis.overdueJobs > 0) attentionFlags.push(dash.kpis.overdueJobs + ' job(s) overdue');
  if (dash.kpis.overduePayments > 0) attentionFlags.push(dash.kpis.overduePayments + ' payment(s) overdue past threshold');
  if (dash.kpis.filesStuck > 0) attentionFlags.push(dash.kpis.filesStuck + ' file(s) stuck beyond threshold');
  if (dash.kpis.highSeverityIncidents > 0) attentionFlags.push(dash.kpis.highSeverityIncidents + ' unresolved high-severity incident(s)');
  kpiAnalysis.forEach(function (u) {
    u.metrics.forEach(function (m) { if (!m.onTrack) attentionFlags.push(u.unit + ': "' + m.label + '" off target'); });
  });
  return { dashboard: dash, kpiAnalysis: kpiAnalysis, attentionFlags: attentionFlags, generatedAt: nowIso_() };
}
