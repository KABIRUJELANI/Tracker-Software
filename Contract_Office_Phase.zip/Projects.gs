/**
 * Projects.gs — Project Management Plan & Analysis (module 16)
 * Plans, timelines, milestones, and progress across all three units.
 */

function listProjects(filters) {
  requirePermission_('projects', 'read');
  return applyFilters_(readAll_('Projects'), filters).map(function (p) {
    var milestones = [];
    try { milestones = JSON.parse(p.milestonesJson || '[]'); } catch (e) {}
    return Object.assign({}, p, { milestones: milestones });
  });
}

function saveProject(record) {
  requirePermission_('projects', 'write');
  var user = getCurrentUser();
  if (record.milestones) {
    record.milestonesJson = JSON.stringify(record.milestones);
    delete record.milestones;
  }
  if (record._row) {
    updateRecord_('Projects', record._row, record);
  } else {
    record.id = genId_('PRJ');
    record.createdBy = user.email;
    record.createdAt = nowIso_();
    record.status = record.status || 'Active';
    record.progressPercent = record.progressPercent || 0;
    appendRecord_('Projects', record);
  }
  logAudit_('project_saved', 'projects', record.id, record.name || '');
  return { ok: true, id: record.id };
}
