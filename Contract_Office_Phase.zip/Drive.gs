/**
 * Drive.gs
 * Evidence photo/document uploads for Daily Reports, Incidents, and Contracts.
 * Stores files in a structured folder tree: Rumbu Contract Dept / <unit> / <module> / <yyyy-MM-dd> /
 * and returns the Drive link to store back on the record.
 */

var ROOT_FOLDER_NAME = 'Rumbu Contract Dept Evidence';

function getOrCreateFolder_(parent, name) {
  var it = parent.getFoldersByName(name);
  return it.hasNext() ? it.next() : parent.createFolder(name);
}

function getRootFolder_() {
  var it = DriveApp.getRootFolder().getFoldersByName(ROOT_FOLDER_NAME);
  return it.hasNext() ? it.next() : DriveApp.createFolder(ROOT_FOLDER_NAME);
}

/**
 * Generates a real PDF (not a browser print-to-PDF) for any single record —
 * used by every module's "Download PDF" action. Builds a temporary Google Doc,
 * exports it to PDF bytes, then deletes the temp Doc so it doesn't clutter
 * Drive. Returns base64 PDF content for the client to turn into a download —
 * nothing is left behind in Drive after this call.
 *
 * fields: array of {label, value}
 */
function generateRecordPdf(title, subtitle, fields) {
  var doc = DocumentApp.create('tmp-pdf-' + Utilities.getUuid());
  var body = doc.getBody();
  body.appendParagraph('RUMBU INDUSTRIES GROUP').setHeading(DocumentApp.ParagraphHeading.HEADING1);
  body.appendParagraph('Agriwatts Nigeria Limited · Contract Office · CONFIDENTIAL').setItalic(true).setFontSize(9);
  body.appendParagraph('');
  body.appendParagraph(title || 'Record').setHeading(DocumentApp.ParagraphHeading.HEADING2);
  if (subtitle) body.appendParagraph(subtitle).setFontSize(10).setForegroundColor('#666666');
  body.appendParagraph('');

  (fields || []).forEach(function (f) {
    var label = body.appendParagraph(f.label + ':');
    label.editAsText().setBold(true).setFontSize(10);
    body.appendParagraph(f.value || '—').setFontSize(11);
    body.appendParagraph('');
  });

  body.appendParagraph('Printed ' + fmtDate_(new Date()) + ' WAT via the Contract Department platform.').setFontSize(8).setForegroundColor('#999999');
  doc.saveAndClose();

  var fileId = doc.getId();
  var pdfBlob = DriveApp.getFileById(fileId).getAs('application/pdf');
  var base64 = Utilities.base64Encode(pdfBlob.getBytes());
  DriveApp.getFileById(fileId).setTrashed(true); // cleanup — this was only ever a conversion scratchpad

  var safeName = String(title || 'Record').replace(/[^a-zA-Z0-9]+/g, '_').slice(0, 60);
  return { base64: base64, filename: safeName + '.pdf' };
}

/**
 * uploadEvidence(base64Data, mimeType, filename, unit, moduleKey) — called from the
 * client with a file read via FileReader.readAsDataURL, base64 payload only (no data: prefix).
 */
function uploadEvidence(base64Data, mimeType, filename, unit, moduleKey) {
  var root = getRootFolder_();
  var unitFolder = getOrCreateFolder_(root, unit || 'Unassigned');
  var moduleFolder = getOrCreateFolder_(unitFolder, moduleKey || 'General');
  var dateFolder = getOrCreateFolder_(moduleFolder, Utilities.formatDate(new Date(), APP_TZ, 'yyyy-MM-dd'));

  var bytes = Utilities.base64Decode(base64Data);
  var blob = Utilities.newBlob(bytes, mimeType, filename);
  var file = dateFolder.createFile(blob);
  file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);

  logAudit_('evidence_uploaded', moduleKey, filename, unit);
  return { url: file.getUrl(), id: file.getId(), name: file.getName() };
}

/**
 * Private upload for sensitive images (director / shareholder / PSC signature and
 * passport). Unlike uploadEvidence(), the file is NOT link-shared: only the account
 * that owns the script can open it in Drive. The app shows it to permitted users
 * through getCompanyPersonImage() instead. Folder: Root / Companies / companyPersons / <companyId>
 */
function uploadPrivateFile_(base64Data, mimeType, filename, companyId) {
  var root = getRootFolder_();
  var companies = getOrCreateFolder_(root, 'Companies');
  var persons = getOrCreateFolder_(companies, 'companyPersons');
  var folder = getOrCreateFolder_(persons, companyId || 'Unassigned');
  var blob = Utilities.newBlob(Utilities.base64Decode(base64Data), mimeType, filename);
  var file = folder.createFile(blob);
  logAudit_('private_file_uploaded', 'companies', filename, companyId || '');
  return { id: file.getId(), name: file.getName() };
}
