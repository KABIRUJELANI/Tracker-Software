/**
 * DailyReports.gs
 * Daily activity/site-visit reporting, with an emergency fast-path that
 * bypasses the normal cadence (auto-creates a linked Incident + immediate
 * escalation instead of waiting for the daily/weekly cycle).
 */

function listDailyReports(filters) {
  requirePermission_('dailyReports', 'read');
  var rows = readAll_('DailyReports');
  return applyFilters_(rows, filters);
}

function saveDailyReport(record) {
  requirePermission_('dailyReports', 'write');
  var user = getCurrentUser();
  record.staffEmail = user.email;
  record.staffName = user.name;
  record.createdAt = nowIso_();
  record.status = 'Submitted';
  if (!record.date) record.date = new Date();

  if (record._row) {
    updateRecord_('DailyReports', record._row, record);
  } else {
    record.id = genId_('DR');
    appendRecord_('DailyReports', record);
  }

  // Record any file movement mentioned on the report, feeding File Positional Analysis.
  if (record.fileRef && record.fileLocation) {
    appendRecord_('FileMovements', {
      id: genId_('FM'), date: record.date, unit: record.unit, fileRef: record.fileRef,
      location: record.fileLocation, reportedBy: user.email, dailyReportId: record.id, createdAt: nowIso_()
    });
  }

  // Emergency fast-path: create/escalate an Incident immediately, do not wait for
  // the normal reporting cycle or a compliance scan.
  if (record.isEmergency) {
    var incidentId = genId_('INC');
    appendRecord_('Incidents', {
      id: incidentId, date: record.date, unit: record.unit, department: record.department,
      reportedBy: user.email, category: 'Emergency', description: record.emergencyDetails || record.activitySummary,
      severity: 'High', status: 'Open', escalatedTo: '', escalatedAt: '', resolvedAt: '',
      followUpNotes: 'Auto-created from Daily Report ' + record.id, evidenceLink: record.evidenceLink || '', createdAt: nowIso_()
    });
    escalateNow_('incidents', incidentId, record.unit, 'Emergency reported via Daily Report ' + record.id, 'High');
  }

  logAudit_('daily_report_saved', 'dailyReports', record.id, JSON.stringify({ unit: record.unit, isEmergency: record.isEmergency }));
  return { ok: true, id: record.id };
}

function deleteDailyReport(id) {
  requirePermission_('dailyReports', 'write');
  var rows = readAll_('DailyReports');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Report not found: ' + id);
  deleteRow_('DailyReports', row._row);
  logAudit_('daily_report_deleted', 'dailyReports', id, '');
  return true;
}

/** One-call "just upload a report" path: stores the file in Drive and creates
 *  a minimal DailyReports row pointing at it — for staff who'd rather submit a
 *  photo/PDF of a report than fill in the structured form. */
function uploadDailyReportFile(base64Data, mimeType, filename, unit, note) {
  requirePermission_('dailyReports', 'write');
  var uploaded = uploadEvidence(base64Data, mimeType, filename, unit, 'dailyReports');
  var record = {
    unit: unit, department: '', siteVisited: '', activitySummary: note || ('Uploaded report: ' + filename),
    isEmergency: false, emergencyDetails: '', evidenceLink: uploaded.url, date: new Date()
  };
  return saveDailyReport(record);
}

/** Report-compliance view: for a given date (default today), who has/hasn't submitted. */
function getReportCompliance(dateStr) {
  requirePermission_('dailyReports', 'read');
  var targetDate = dateStr ? new Date(dateStr) : new Date();
  var targetKey = Utilities.formatDate(targetDate, APP_TZ, 'yyyy-MM-dd');
  var reports = readAll_('DailyReports').filter(function (r) {
    return Utilities.formatDate(new Date(r.date), APP_TZ, 'yyyy-MM-dd') === targetKey;
  });
  var submittedEmails = {};
  reports.forEach(function (r) { submittedEmails[String(r.staffEmail).toLowerCase()] = true; });

  var staff = getStaffList().filter(function (u) { return u.active !== false && u.role !== 'CEO' && u.role !== 'Admin'; });
  return staff.map(function (u) {
    return { email: u.email, name: u.name, unit: u.unit, department: u.department, submitted: !!submittedEmails[String(u.email).toLowerCase()] };
  });
}

/** Scheduled: flag anyone who has not submitted by the configured cutoff hour. Called by Triggers.gs. */
function runDailyComplianceCheck_() {
  var cutoffHour = Number(getSetting('dailyReportComplianceCutoffHour', 17));
  var nowHour = Number(Utilities.formatDate(new Date(), APP_TZ, 'H'));
  if (nowHour < cutoffHour) return; // trigger fires multiple times a day; only act after cutoff

  var compliance = getReportCompliance();
  var missing = compliance.filter(function (c) { return !c.submitted; });
  if (!missing.length) return;

  missing.forEach(function (m) {
    escalateNow_('dailyReports', m.email, m.unit, 'No daily report submitted by ' + m.name + ' (' + m.department + ') by cutoff.', 'Medium');
  });
}
