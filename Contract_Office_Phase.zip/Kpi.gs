/**
 * Kpi.gs — KPI Analysis (module 13)
 * Departmental performance against configurable targets, sliceable by unit
 * and by staff member. Targets live in the KpiTargets sheet, editable from Admin.
 */

var KPI_METRICS = [
  { key: 'jobCompletionRate', label: 'Job Completion Rate (%)', defaultTarget: 85 },
  { key: 'avgTurnaroundDays', label: 'Avg. Job Turnaround (days)', defaultTarget: 10, lowerIsBetter: true },
  { key: 'paymentClosureRate', label: 'Payment Closure Rate (%)', defaultTarget: 80 },
  { key: 'fileStuckRate', label: 'Files Stuck (%)', defaultTarget: 10, lowerIsBetter: true },
  { key: 'dailyReportComplianceRate', label: 'Daily Report Compliance (%)', defaultTarget: 95 }
];

function getKpiTargets() {
  requirePermission_('kpi', 'read');
  return readAll_('KpiTargets');
}

function saveKpiTarget(record) {
  requirePermission_('kpi', 'write');
  var rows = readAll_('KpiTargets');
  var existing = rows.filter(function (r) { return r.metric === record.metric && r.unit === record.unit; })[0];
  if (existing) {
    updateRecord_('KpiTargets', existing._row, { target: record.target, period: record.period, updatedAt: nowIso_() });
  } else {
    appendRecord_('KpiTargets', { metric: record.metric, unit: record.unit, target: record.target, period: record.period || 'Monthly', updatedAt: nowIso_() });
  }
  return true;
}

function getKpiAnalysis(unitFilter) {
  requirePermission_('kpi', 'read');
  var units = getUnits().map(function (u) { return u.unitId; });
  var targets = getKpiTargets();
  var targetFor = function (metric, unit) {
    var t = targets.filter(function (t) { return t.metric === metric && t.unit === unit; })[0];
    return t ? Number(t.target) : KPI_METRICS.filter(function (m) { return m.key === metric; })[0].defaultTarget;
  };

  var unitsToRun = unitFilter ? [unitFilter] : units;
  var out = [];
  unitsToRun.forEach(function (u) {
    var jobKpi = getJobKpis(u);
    var payments = listPayments({ unit: u });
    var paymentClosureRate = payments.length ? Math.round((payments.filter(function (p) { return p.status === 'Completed'; }).length / payments.length) * 100) : 0;
    var fileAnalysis = getFilePositionalAnalysis({ unit: u });
    var fileStuckRate = fileAnalysis.length ? Math.round((fileAnalysis.filter(function (f) { return f.isStuck; }).length / fileAnalysis.length) * 100) : 0;
    var compliance = getReportCompliance().filter(function (c) { return c.unit === u; });
    var complianceRate = compliance.length ? Math.round((compliance.filter(function (c) { return c.submitted; }).length / compliance.length) * 100) : 0;

    var metrics = [
      { key: 'jobCompletionRate', actual: jobKpi.completionRate },
      { key: 'avgTurnaroundDays', actual: jobKpi.avgTurnaroundDays },
      { key: 'paymentClosureRate', actual: paymentClosureRate },
      { key: 'fileStuckRate', actual: fileStuckRate },
      { key: 'dailyReportComplianceRate', actual: complianceRate }
    ].map(function (m) {
      var meta = KPI_METRICS.filter(function (k) { return k.key === m.key; })[0];
      var target = targetFor(m.key, u);
      var onTrack = meta.lowerIsBetter ? m.actual <= target : m.actual >= target;
      return { key: m.key, label: meta.label, actual: m.actual, target: target, onTrack: onTrack, lowerIsBetter: !!meta.lowerIsBetter };
    });
    out.push({ unit: u, metrics: metrics });
  });
  return out;
}

/** Scheduled: any metric off-track by a wide margin gets pushed to CEO/Management. */
function runKpiScan_() {
  var analysis = getKpiAnalysis();
  analysis.forEach(function (unitBlock) {
    unitBlock.metrics.forEach(function (m) {
      if (!m.onTrack) {
        var gap = m.lowerIsBetter ? (m.actual - m.target) : (m.target - m.actual);
        if (gap > 15) { // material miss, not a rounding-error miss
          escalateIfNew_('kpi', unitBlock.unit + ':' + m.key, unitBlock.unit,
            unitBlock.unit + ' is off-target on "' + m.label + '": actual ' + m.actual + ' vs target ' + m.target + '.', 'Medium', 24 * 6);
        }
      }
    });
  });
}
