/**
 * Jobs.gs — Jobs / Analysis + Pending Jobs Analysis (module 12 rolls this up)
 * Status is one of: Untouched (not started) | In Progress (uncompleted) |
 * Completed | Overdue (manually flagged). "Overdue" is also computed
 * automatically from the due date regardless of manual status — see the
 * `overdue` boolean withAgeing_ adds to every job, shown as a badge alongside
 * whatever status is actually selected.
 */

var JOB_STATUSES = ['Untouched', 'In Progress', 'Completed', 'Overdue'];

function listJobs(filters) {
  requirePermission_('jobs', 'read');
  return withAgeing_(applyFilters_(readAll_('Jobs'), filters));
}

function withAgeing_(jobs) {
  var today = new Date();
  return jobs.map(function (j) {
    var ageDays = j.startDate ? daysBetween_(new Date(j.startDate), today) : (j.createdAt ? daysBetween_(new Date(j.createdAt), today) : null);
    var overdue = j.dueDate && j.status !== 'Completed' && new Date(j.dueDate) < today;
    return Object.assign({}, j, { ageDays: ageDays, overdue: overdue });
  });
}

function saveJob(record) {
  requirePermission_('jobs', 'write');
  var user = getCurrentUser();
  if (record._row) {
    if (record.status === 'Completed' && !record.completedDate) record.completedDate = new Date();
    if (record.status === 'In Progress' && !record.startDate) record.startDate = new Date();
    updateRecord_('Jobs', record._row, record);
    logAudit_('job_updated', 'jobs', record.id, record.status || '');
  } else {
    record.id = genId_('JOB');
    record.createdBy = user.email;
    record.createdAt = nowIso_();
    record.status = record.status || 'Untouched';
    appendRecord_('Jobs', record);
    logAudit_('job_created', 'jobs', record.id, record.title || '');
  }
  return { ok: true, id: record.id };
}

function deleteJob(id) {
  requirePermission_('jobs', 'write');
  var rows = readAll_('Jobs');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Job not found: ' + id);
  deleteRow_('Jobs', row._row);
  logAudit_('job_deleted', 'jobs', id, '');
  return true;
}

/** Pending Jobs Analysis (module 12): rollup of uncompleted vs untouched with ageing buckets. */
function getPendingJobsAnalysis(filters) {
  requirePermission_('jobs', 'read');
  var jobs = withAgeing_(applyFilters_(readAll_('Jobs'), filters)).filter(function (j) { return j.status !== 'Completed'; });
  var buckets = { '0-3 days': [], '4-7 days': [], '8-14 days': [], '15+ days': [] };
  jobs.forEach(function (j) {
    var age = j.ageDays || 0;
    if (age <= 3) buckets['0-3 days'].push(j);
    else if (age <= 7) buckets['4-7 days'].push(j);
    else if (age <= 14) buckets['8-14 days'].push(j);
    else buckets['15+ days'].push(j);
  });
  return {
    untouched: jobs.filter(function (j) { return j.status === 'Untouched'; }),
    inProgress: jobs.filter(function (j) { return j.status === 'In Progress'; }),
    manuallyOverdue: jobs.filter(function (j) { return j.status === 'Overdue'; }),
    ageingBuckets: buckets
  };
}

/** KPI feed for Jobs: completion rate + average turnaround time. Used by Kpi.gs. */
function getJobKpis(unit) {
  var jobs = readAll_('Jobs').filter(function (j) { return !unit || j.unit === unit; });
  var completed = jobs.filter(function (j) { return j.status === 'Completed'; });
  var completionRate = jobs.length ? Math.round((completed.length / jobs.length) * 100) : 0;
  var turnaroundDays = completed
    .filter(function (j) { return j.startDate && j.completedDate; })
    .map(function (j) { return daysBetween_(new Date(j.startDate), new Date(j.completedDate)); });
  var avgTurnaround = turnaroundDays.length ? Math.round(turnaroundDays.reduce(function (a, b) { return a + b; }, 0) / turnaroundDays.length) : 0;
  return { completionRate: completionRate, avgTurnaroundDays: avgTurnaround, total: jobs.length, completed: completed.length };
}

/** Scheduled scan: escalate untouched jobs past threshold and high-priority delayed jobs. */
function runJobsScan_() {
  var untouchedThreshold = Number(getSetting('jobUntouchedDaysThreshold', 3));
  var delayedThreshold = Number(getSetting('jobDelayedDaysThreshold', 7));
  var jobs = withAgeing_(readAll_('Jobs'));

  jobs.forEach(function (j) {
    if (j.status === 'Untouched' && j.ageDays >= untouchedThreshold) {
      escalateIfNew_('jobs', j.id, j.unit, 'Job "' + j.title + '" untouched for ' + j.ageDays + ' day(s).', 'Medium');
    }
    if (j.status !== 'Completed' && j.overdue) {
      var overdueDays = daysBetween_(new Date(j.dueDate), new Date());
      if (overdueDays >= delayedThreshold || j.priority === 'High') {
        escalateIfNew_('jobs', j.id, j.unit, 'Job "' + j.title + '" is overdue by ' + overdueDays + ' day(s) (priority: ' + j.priority + ').', j.priority === 'High' ? 'High' : 'Medium');
      }
    }
  });
}
