/**
 * Companies.gs — Company Analysis (module 15)
 * Central contractor/company register: RC number, year of incorporation,
 * compliance checklist (TCC, PEN, ITF, NSITF, BPP, 3-AFS, PROFILE), directors /
 * shareholders / PSC records, pending-status companies, missing account numbers,
 * GIFMIS linkage and ownership records.
 */

/** The seven compliance items ticked per company. key = column in the Companies sheet. */
var COMPANY_CHECKLIST = [
  { key: 'chkTCC', label: 'TCC' }, { key: 'chkPEN', label: 'PEN' }, { key: 'chkITF', label: 'ITF' },
  { key: 'chkNSITF', label: 'NSITF' }, { key: 'chkBPP', label: 'BPP' }, { key: 'chkAFS3', label: '3-AFS' },
  { key: 'chkProfile', label: 'PROFILE' }
];

/** The five people records held per company. */
var COMPANY_PERSON_ROLES = ['Director 1', 'Director 2', 'Shareholder 1', 'Shareholder 2', 'PSC'];
var PERSON_TEXT_FIELDS = ['name', 'bvn', 'nin', 'address', 'email', 'phone'];
/** Columns stored as plain text so leading zeros (08012345678, 0123...) are never lost. */
var PERSON_TEXT_COLS_ = ['bvn', 'nin', 'phone'];

function truthy_(v) { return v === true || v === 'TRUE' || v === 'true' || v === 1 || v === '1'; }

/** Self-migrating: adds any missing columns / the CompanyPersons sheet the first
 *  time the Company screens are used, so a forgotten "Run full setup" cannot cause
 *  ticks or director details to be silently lost. Cached for one hour. */
function ensureCompanySchema_() {
  var cache = CacheService.getScriptCache();
  if (cache.get('companySchemaOk')) return;
  ensureSheet_('Companies', SHEET_SCHEMAS.Companies);
  var ps = ensureSheet_('CompanyPersons', SHEET_SCHEMAS.CompanyPersons);
  var headers = ps.getRange(1, 1, 1, ps.getLastColumn()).getValues()[0];
  PERSON_TEXT_COLS_.forEach(function (c) {
    var col = headers.indexOf(c);
    if (col !== -1) ps.getRange(2, col + 1, Math.max(ps.getMaxRows() - 1, 1), 1).setNumberFormat('@');
  });
  delete _sheetCache_['Companies'];
  cache.put('companySchemaOk', '1', 3600);
}

/** Writes ONE cell. Used for ticks so two people ticking different boxes on the
 *  same company at the same moment cannot overwrite each other's change. */
function setCell_(sheetName, rowNum, field, value) {
  var sh = sheet_(sheetName);
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  var col = headers.indexOf(field);
  if (col === -1) throw new Error('Column "' + field + '" is missing in sheet "' + sheetName + '". Run Rumbu Admin > 1) Run full setup.');
  sh.getRange(rowNum, col + 1).setValue(value);
  delete _sheetCache_[sheetName];
}

function withLock_(fn) {
  var lock = LockService.getScriptLock();
  lock.waitLock(15000);
  try { return fn(); } finally { lock.releaseLock(); }
}

function listCompanies(filters) {
  requirePermission_('companies', 'read');
  ensureCompanySchema_();
  return applyFilters_(readAll_('Companies'), filters);
}

/** filters.year: a 4-digit year, or 'none' for companies with no year recorded. */
function getCompanyAnalysis(filters) {
  requirePermission_('companies', 'read');
  ensureCompanySchema_();
  var f = filters || {};
  var allRows = readAll_('Companies');

  var yearSet = {}; var hasUnknownYear = false;
  allRows.forEach(function (c) {
    var y = Number(c.incorporationYear);
    if (y > 0) yearSet[y] = true; else hasUnknownYear = true;
  });
  var years = Object.keys(yearSet).map(Number).sort(function (a, b) { return b - a; });

  var companies = applyFilters_(allRows, f);
  if (f.year === 'none') {
    companies = companies.filter(function (c) { return !(Number(c.incorporationYear) > 0); });
  } else if (f.year) {
    companies = companies.filter(function (c) { return Number(c.incorporationYear) === Number(f.year); });
  }

  var peopleCount = {};
  try {
    readAll_('CompanyPersons').forEach(function (p) {
      if (p.name || p.bvn || p.nin || p.signatureFileId || p.passportFileId) peopleCount[p.companyId] = (peopleCount[p.companyId] || 0) + 1;
    });
  } catch (e) { /* CompanyPersons not created yet: show 0 */ }

  companies = companies.map(function (c) {
    var out = Object.assign({}, c, { gifmisLinked: truthy_(c.gifmisLinked), peopleCount: peopleCount[c.id] || 0 });
    COMPANY_CHECKLIST.forEach(function (k) { out[k.key] = truthy_(c[k.key]); });
    return out;
  });

  return {
    total: companies.length,
    pending: companies.filter(function (c) { return c.status === 'Pending'; }),
    missingAccountNumber: companies.filter(function (c) { return !c.accountNumber; }),
    gifmisNotLinked: companies.filter(function (c) { return !c.gifmisLinked; }),
    all: companies,
    years: years,
    hasUnknownYear: hasUnknownYear
  };
}

function validateCompanyFields_(record) {
  if (!record.name || !String(record.name).trim()) throw new Error('Company name is required.');
  record.name = String(record.name).replace(/\s+/g, ' ').trim();
  if (record.rcNumber !== undefined && record.rcNumber !== null && String(record.rcNumber).trim() !== '') {
    var rc = String(record.rcNumber).trim().replace(/^RC[\s-]*/i, '');
    if (!/^\d{1,9}$/.test(rc)) throw new Error('RC number must be digits only (for example 1509078).');
    record.rcNumber = Number(rc);
  } else { record.rcNumber = ''; }
  if (record.incorporationYear !== undefined && record.incorporationYear !== null && String(record.incorporationYear).trim() !== '') {
    var y = Number(record.incorporationYear);
    var maxYear = Number(Utilities.formatDate(new Date(), APP_TZ, 'yyyy'));
    if (!(y >= 1900 && y <= maxYear)) throw new Error('Year of incorporation must be between 1900 and ' + maxYear + '.');
    record.incorporationYear = y;
  } else { record.incorporationYear = ''; }
}

function saveCompany(record) {
  requirePermission_('companies', 'write');
  ensureCompanySchema_();
  validateCompanyFields_(record);
  return withLock_(function () {
    var rows = readAll_('Companies');
    var sameKey = rows.filter(function (c) { return companyKey_(c.name, c.rcNumber) === companyKey_(record.name, record.rcNumber) && c.id !== record.id; })[0];
    if (sameKey) throw new Error('"' + record.name + '" with RC number ' + (record.rcNumber || '(none)') + ' is already in the register.');

    // Ticks are changed only through saveCompanyChecklist, never by an edit form.
    COMPANY_CHECKLIST.forEach(function (k) { delete record[k.key]; });
    delete record.peopleCount;

    if (record.id) {
      var existing = rows.filter(function (c) { return c.id === record.id; })[0];
      if (!existing) throw new Error('Company not found: ' + record.id);
      record._row = existing._row; // never trust the row number sent by the browser
      updateRecord_('Companies', existing._row, record);
      logAudit_('company_updated', 'companies', record.id, '');
    } else {
      record.id = genId_('CO');
      record.status = record.status || 'Pending';
      record.createdAt = nowIso_();
      var maxSerial = rows.reduce(function (m, c) { return Math.max(m, Number(c.serialNo) || 0); }, 0);
      record.serialNo = maxSerial + 1;
      COMPANY_CHECKLIST.forEach(function (k) { record[k.key] = false; });
      delete record._row;
      appendRecord_('Companies', record);
      logAudit_('company_created', 'companies', record.id, record.name || '');
    }
    invalidateCache_('companies');
    return { ok: true, id: record.id };
  });
}

/** Tick / untick one checklist item. Only whitelisted columns can be written. */
function saveCompanyChecklist(companyId, field, value) {
  requirePermission_('companies', 'write');
  ensureCompanySchema_();
  if (!COMPANY_CHECKLIST.some(function (k) { return k.key === field; })) throw new Error('Unknown checklist item: ' + field);
  return withLock_(function () {
    var row = readAll_('Companies').filter(function (c) { return c.id === companyId; })[0];
    if (!row) throw new Error('Company not found: ' + companyId);
    var v = value === true || value === 'true';
    setCell_('Companies', row._row, field, v);
    logAudit_('company_checklist', 'companies', companyId, field + '=' + v);
    return { ok: true, field: field, value: v };
  });
}

function deleteCompany(id) {
  requirePermission_('companies', 'write');
  var rows = readAll_('Companies');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Company not found: ' + id);
  withLock_(function () {
    purgeCompanyPersons_(id);
    deleteRow_('Companies', row._row);
  });
  invalidateCache_('companies');
  logAudit_('company_deleted', 'companies', id, '');
  return true;
}

/* ---------------- Directors, shareholders and PSC ----------------
 * One row per (company, role) in the CompanyPersons sheet. Signature and passport
 * images are stored in Drive as PRIVATE files (not link-shared). The browser never
 * receives a Drive link: images are fetched through getCompanyPersonImage(), which
 * checks the caller's permission every time. */

function personRoleCheck_(role) {
  if (COMPANY_PERSON_ROLES.indexOf(role) === -1) throw new Error('Unknown role: ' + role);
}

function companyExists_(companyId) {
  var c = readAll_('Companies').filter(function (r) { return r.id === companyId; })[0];
  if (!c) throw new Error('Company not found: ' + companyId);
  return c;
}

function findPerson_(companyId, role) {
  return readAll_('CompanyPersons').filter(function (p) { return p.companyId === companyId && p.role === role; })[0] || null;
}

function getCompanyPersons(companyId) {
  requirePermission_('companies', 'read');
  ensureCompanySchema_();
  companyExists_(companyId);
  var rows = readAll_('CompanyPersons').filter(function (p) { return p.companyId === companyId; });
  return COMPANY_PERSON_ROLES.map(function (role) {
    var p = rows.filter(function (r) { return r.role === role; })[0];
    var out = { role: role, exists: !!p, updatedAt: p ? p.updatedAt : '', updatedBy: p ? p.updatedBy : '',
      hasSignature: !!(p && p.signatureFileId), hasPassport: !!(p && p.passportFileId) };
    PERSON_TEXT_FIELDS.forEach(function (f) { out[f] = p && p[f] !== undefined && p[f] !== null ? String(p[f]) : ''; });
    return out;
  });
}

function upsertPerson_(companyId, role, patch) {
  var sh = sheet_('CompanyPersons');
  var headers = sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0];
  var existing = findPerson_(companyId, role);
  var rowNum;
  if (existing) {
    rowNum = existing._row;
  } else {
    rowNum = Math.max(sh.getLastRow(), 1) + 1;
    if (rowNum > sh.getMaxRows()) sh.insertRowsAfter(sh.getMaxRows(), 20);
  }
  headers.forEach(function (h, i) {
    if (PERSON_TEXT_COLS_.indexOf(h) !== -1) sh.getRange(rowNum, i + 1).setNumberFormat('@');
  });
  var base = existing ? {} : { id: genId_('CP'), companyId: companyId, role: role };
  var full = Object.assign(base, patch, { updatedAt: nowIso_(), updatedBy: currentUserEmail_() });
  updateRecord_('CompanyPersons', rowNum, full);
  return rowNum;
}

function saveCompanyPerson(companyId, role, data) {
  requirePermission_('companies', 'write');
  ensureCompanySchema_();
  personRoleCheck_(role);
  companyExists_(companyId);
  data = data || {};
  var clean = {};
  PERSON_TEXT_FIELDS.forEach(function (f) { clean[f] = String(data[f] === undefined || data[f] === null ? '' : data[f]).trim(); });
  clean.bvn = clean.bvn.replace(/[\s-]/g, '');
  clean.nin = clean.nin.replace(/[\s-]/g, '');
  if (clean.bvn && !/^\d{11}$/.test(clean.bvn)) throw new Error(role + ': BVN must be exactly 11 digits.');
  if (clean.nin && !/^\d{11}$/.test(clean.nin)) throw new Error(role + ': NIN must be exactly 11 digits.');
  if (clean.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(clean.email)) throw new Error(role + ': email address is not valid.');
  if (clean.phone && !/^[+]?[\d\s-]{7,20}$/.test(clean.phone)) throw new Error(role + ': phone number is not valid.');
  withLock_(function () { upsertPerson_(companyId, role, clean); });
  logAudit_('company_person_saved', 'companies', companyId, role); // role only: never log BVN / NIN values
  return { ok: true };
}

var PERSON_IMAGE_KINDS_ = { signature: 'signatureFileId', passport: 'passportFileId' };

function uploadCompanyPersonImage(companyId, role, kind, base64Data, mimeType, filename) {
  requirePermission_('companies', 'write');
  ensureCompanySchema_();
  personRoleCheck_(role);
  var company = companyExists_(companyId);
  var col = PERSON_IMAGE_KINDS_[kind];
  if (!col) throw new Error('Image type must be "signature" or "passport".');
  if (!/^image\/(jpeg|png|gif|webp)$/.test(String(mimeType))) throw new Error('Only image files (JPG, PNG, GIF, WEBP) are accepted.');
  if (!base64Data || String(base64Data).length > 5 * 1024 * 1024) throw new Error('Image is too large. Use a photo under about 3 MB.');
  var ext = { 'image/jpeg': 'jpg', 'image/png': 'png', 'image/gif': 'gif', 'image/webp': 'webp' }[mimeType];
  var niceName = (company.name + ' - ' + role + ' - ' + kind + '.' + ext).replace(/[\\\/:*?"<>|]+/g, '');
  return withLock_(function () {
    var existing = findPerson_(companyId, role);
    var oldId = existing ? existing[col] : '';
    var saved = uploadPrivateFile_(base64Data, mimeType, niceName, company.id);
    var patch = {}; patch[col] = saved.id;
    upsertPerson_(companyId, role, patch);
    if (oldId) { try { DriveApp.getFileById(oldId).setTrashed(true); } catch (e) { /* already gone */ } }
    logAudit_('company_person_image_uploaded', 'companies', companyId, role + ' ' + kind);
    return { ok: true };
  });
}

function getCompanyPersonImage(companyId, role, kind) {
  requirePermission_('companies', 'read');
  personRoleCheck_(role);
  var col = PERSON_IMAGE_KINDS_[kind];
  if (!col) throw new Error('Image type must be "signature" or "passport".');
  var p = findPerson_(companyId, role);
  if (!p || !p[col]) return null;
  var file;
  try { file = DriveApp.getFileById(p[col]); } catch (e) { return null; }
  var blob = file.getBlob();
  return { dataUrl: 'data:' + blob.getContentType() + ';base64,' + Utilities.base64Encode(blob.getBytes()), filename: file.getName() };
}

function deleteCompanyPersonImage(companyId, role, kind) {
  requirePermission_('companies', 'write');
  personRoleCheck_(role);
  var col = PERSON_IMAGE_KINDS_[kind];
  if (!col) throw new Error('Image type must be "signature" or "passport".');
  return withLock_(function () {
    var p = findPerson_(companyId, role);
    if (!p || !p[col]) return true;
    try { DriveApp.getFileById(p[col]).setTrashed(true); } catch (e) { /* already gone */ }
    setCell_('CompanyPersons', p._row, col, '');
    logAudit_('company_person_image_deleted', 'companies', companyId, role + ' ' + kind);
    return true;
  });
}

/** Clears one person slot completely (record and both images). */
function deleteCompanyPerson(companyId, role) {
  requirePermission_('companies', 'write');
  personRoleCheck_(role);
  return withLock_(function () {
    var p = findPerson_(companyId, role);
    if (!p) return true;
    ['signatureFileId', 'passportFileId'].forEach(function (col) {
      if (p[col]) { try { DriveApp.getFileById(p[col]).setTrashed(true); } catch (e) {} }
    });
    deleteRow_('CompanyPersons', p._row);
    logAudit_('company_person_deleted', 'companies', companyId, role);
    return true;
  });
}

/** Removes every person row (and their images) for a company being deleted. */
function purgeCompanyPersons_(companyId) {
  var rows;
  try { rows = readAll_('CompanyPersons').filter(function (p) { return p.companyId === companyId; }); } catch (e) { return; }
  rows.sort(function (a, b) { return b._row - a._row; }); // bottom first so row numbers stay valid
  rows.forEach(function (p) {
    ['signatureFileId', 'passportFileId'].forEach(function (col) {
      if (p[col]) { try { DriveApp.getFileById(p[col]).setTrashed(true); } catch (e) {} }
    });
    deleteRow_('CompanyPersons', p._row);
  });
}

/** The fixed 14-item compliance/document checklist requested for every
 *  company. Same one-slot-per-type pattern as Contract Documents. */
var COMPANY_DOC_TYPES = [
  'CAC Certificate', 'Status Report', 'MEMART', 'TCC (Tax Clearance Certificate)', 'PENCOM',
  'ITF', 'BPP', 'NSITF', 'Audited Accounts', 'Affidavit', 'Reference Letter',
  'Lease/Equipment', 'CV/Resume', 'Similar Jobs (Award Letters & JCC)'
];

function getCompanyDocumentChecklist(companyId) {
  requirePermission_('companies', 'read');
  var existing = readAll_('CompanyDocuments').filter(function (d) { return d.companyId === companyId; });
  return COMPANY_DOC_TYPES.map(function (docType) {
    var match = existing.filter(function (d) { return d.docType === docType; })[0];
    return { docType: docType, id: match ? match.id : null, driveLink: match ? match.driveLink : '', filename: match ? match.filename : '', notes: match ? match.notes : '', uploadedAt: match ? match.uploadedAt : '' };
  });
}

function uploadCompanyDocument(companyId, docType, base64Data, mimeType, filename) {
  requirePermission_('companies', 'write');
  if (COMPANY_DOC_TYPES.indexOf(docType) === -1) throw new Error('Unknown document type: ' + docType);
  var user = getCurrentUser();
  var uploaded = uploadEvidence(base64Data, mimeType, filename, 'Companies', 'companyDocuments');
  var existing = readAll_('CompanyDocuments').filter(function (d) { return d.companyId === companyId && d.docType === docType; })[0];
  if (existing) {
    updateRecord_('CompanyDocuments', existing._row, { driveLink: uploaded.url, filename: filename, uploadedAt: nowIso_(), uploadedBy: user.email });
  } else {
    appendRecord_('CompanyDocuments', { id: genId_('COD'), companyId: companyId, docType: docType, driveLink: uploaded.url, filename: filename, uploadedAt: nowIso_(), uploadedBy: user.email });
  }
  logAudit_('company_document_uploaded', 'companies', companyId, docType);
  return true;
}

/** The "Manual Entry" counterpart to uploadCompanyDocument — typed
 *  information instead of a file. Same one-slot-per-doc-type row; entering
 *  manual text does not require or replace a file, and vice versa. */
function saveCompanyDocumentNote(companyId, docType, notes) {
  requirePermission_('companies', 'write');
  if (COMPANY_DOC_TYPES.indexOf(docType) === -1) throw new Error('Unknown document type: ' + docType);
  var user = getCurrentUser();
  var existing = readAll_('CompanyDocuments').filter(function (d) { return d.companyId === companyId && d.docType === docType; })[0];
  if (existing) {
    updateRecord_('CompanyDocuments', existing._row, { notes: notes, uploadedAt: nowIso_(), uploadedBy: user.email });
  } else {
    appendRecord_('CompanyDocuments', { id: genId_('COD'), companyId: companyId, docType: docType, driveLink: '', filename: '', notes: notes, uploadedAt: nowIso_(), uploadedBy: user.email });
  }
  logAudit_('company_document_note_saved', 'companies', companyId, docType);
  return true;
}

function deleteCompanyDocument(id) {
  requirePermission_('companies', 'write');
  var rows = readAll_('CompanyDocuments');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Document not found: ' + id);
  deleteRow_('CompanyDocuments', row._row);
  logAudit_('company_document_deleted', 'companies', id, '');
  return true;
}
