/**
 * Escalations.gs
 * Central escalation engine. Every other module calls escalateNow_() to raise
 * an item; this file owns the audit trail, the CEO email, and human acknowledgement.
 * Threshold *detection* (what counts as stuck/overdue/delayed) lives in each
 * module's own scan function (see Jobs.gs, Payments.gs, Files.gs), which is
 * what runEscalationScan_() (Triggers.gs) calls on a schedule.
 *
 * Every email this platform sends — automatic threshold escalations AND direct
 * messages from the compose box — is recorded here with its actual subject and
 * body, so the Escalations page doubles as a sent-mail log: exactly what went
 * out, to whom, and whether it actually sent.
 */

function listEscalations(filters) {
  requirePermission_('escalations', 'read');
  var rows = readAll_('Escalations');
  return applyFilters_(rows, filters).sort(function (a, b) { return new Date(b.date) - new Date(a.date); });
}

/** Raise + email an escalation immediately. Callable from any module's server code. */
function escalateNow_(module, refId, unit, reason, severity) {
  var id = genId_('ESC');
  var target = resolveEscalationTarget_(module);
  var subject = '[Rumbu Contract Dept] Escalation — ' + module + ' — ' + severity;
  var body = 'Module: ' + module + '\nReference: ' + refId + '\nUnit: ' + unit + '\nSeverity: ' + severity + '\nReason: ' + reason;
  var record = {
    id: id, date: new Date(), module: module, refId: refId, unit: unit, reason: reason,
    severity: severity || 'Medium', escalatedTo: target.email, subject: subject, body: body,
    sentAt: '', acknowledged: false, acknowledgedBy: '', acknowledgedAt: '', emailStatus: 'Pending'
  };
  appendRecord_('Escalations', record);
  var row = readAll_('Escalations').filter(function (e) { return e.id === id; })[0];

  try {
    MailApp.sendEmail({
      to: target.email,
      subject: subject,
      htmlBody: '<p><b>RUMBU INDUSTRIES GROUP — Contract Department</b></p>' +
        '<p><b>Module:</b> ' + module + '<br/><b>Reference:</b> ' + refId + '<br/><b>Unit:</b> ' + unit + '<br/>' +
        '<b>Severity:</b> ' + severity + '<br/><b>Reason:</b> ' + reason + '</p>' +
        '<p>Raised: ' + fmtDate_(new Date()) + ' WAT. This is an automated escalation from the Contract Department platform.</p>'
    });
    updateRecord_('Escalations', row._row, { sentAt: nowIso_(), emailStatus: 'Sent' });
  } catch (e) {
    updateRecord_('Escalations', row._row, { emailStatus: 'Failed: ' + e.message });
  }

  logAudit_('escalation_raised', module, refId, reason);
  invalidateCache_('escalations');
  return id;
}

function resolveEscalationTarget_(module) {
  var ceoEmail = getSetting('escalationCeoEmail', 'ceo@example.com');
  // Section-level routing per the dashboard config (DASHBOARD_SECTIONS in SETUP.gs);
  // everything ultimately visible to the CEO, but module-level "first responder" differs.
  var routing = {
    dailyReports: ceoEmail, incidents: ceoEmail, jobs: ceoEmail, payments: ceoEmail,
    contracts: ceoEmail, filePositional: ceoEmail, procurement: ceoEmail, kpi: ceoEmail
  };
  return { email: routing[module] || ceoEmail };
}

function acknowledgeEscalation(id) {
  requirePermission_('escalations', 'read'); // any authenticated viewer may acknowledge; writes are system-only otherwise
  var rows = readAll_('Escalations');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Escalation not found: ' + id);
  updateRecord_('Escalations', row._row, { acknowledged: true, acknowledgedBy: currentUserEmail_(), acknowledgedAt: nowIso_() });
  logAudit_('escalation_acknowledged', row.module, row.refId, '');
  return true;
}

/** Deletes a record from the escalation/sent-mail log. Gated on 'escalations'
 *  write specifically (not just read, unlike acknowledge) because this removes
 *  an audit-trail row permanently — by default that's Admin-only; grant it to
 *  other roles from Admin > Access Control if they need it. */
function deleteEscalationRecord(id) {
  requirePermission_('escalations', 'write');
  var rows = readAll_('Escalations');
  var row = rows.filter(function (r) { return r.id === id; })[0];
  if (!row) throw new Error('Escalation not found: ' + id);
  deleteRow_('Escalations', row._row);
  logAudit_('escalation_deleted', row.module, row.refId, '');
  return true;
}

/** Wipes every escalation/sent-email record — automatic escalations AND
 *  direct messages alike. This is the whole log, not a filtered subset, so
 *  it's gated the same way deleteEscalationRecord is (effectively Admin-only
 *  by default) and logged to AuditLog before the rows disappear. */
function deleteAllEscalations() {
  requirePermission_('escalations', 'write');
  var rows = readAll_('Escalations');
  var count = rows.length;
  rows.sort(function (a, b) { return b._row - a._row; }); // highest row first, so deleting doesn't shift later rows
  rows.forEach(function (r) { deleteRow_('Escalations', r._row); });
  logAudit_('all_escalations_deleted', 'escalations', currentUserEmail_(), count + ' record(s) removed');
  return { removed: count };
}

/** Prevents the daily scan from re-escalating the same still-open item every run. */
function hasRecentEscalation_(module, refId, withinHours) {
  var cutoff = new Date(Date.now() - (withinHours || 24) * 3600 * 1000);
  var rows = readAll_('Escalations');
  return rows.some(function (r) {
    return r.module === module && String(r.refId) === String(refId) && new Date(r.date) > cutoff;
  });
}

/** Wrapper every scan function should use instead of calling escalateNow_ directly. */
function escalateIfNew_(module, refId, unit, reason, severity, cooldownHours) {
  if (hasRecentEscalation_(module, refId, cooldownHours || 24)) return null;
  return escalateNow_(module, refId, unit, reason, severity);
}

/** Ad-hoc direct email — not tied to a threshold breach. Lets anyone with
 *  escalations read access message the CEO or any staff member directly from
 *  inside the platform. Recorded as an Escalations row (module "Direct
 *  Message") with the real subject/body, so it shows up in the same list as
 *  automatic escalations and can be reviewed the same way — acknowledgement
 *  isn't really meaningful for these so they're created pre-acknowledged. */
function sendDirectEmail(toEmail, subject, message) {
  requirePermission_('escalations', 'read');
  if (!toEmail || !subject || !message) throw new Error('To, subject and message are all required.');
  var sender = getCurrentUser();
  var fullSubject = '[Rumbu Contract Dept] ' + subject;
  var id = genId_('ESC');
  var record = {
    id: id, date: new Date(), module: 'Direct Message', refId: toEmail, unit: sender.unit || '',
    reason: subject, severity: 'Info', escalatedTo: toEmail, subject: fullSubject, body: message,
    sentAt: '', acknowledged: true, acknowledgedBy: sender.email, acknowledgedAt: nowIso_(), emailStatus: 'Pending'
  };
  appendRecord_('Escalations', record);
  var row = readAll_('Escalations').filter(function (e) { return e.id === id; })[0];

  try {
    MailApp.sendEmail({
      to: toEmail,
      subject: fullSubject,
      htmlBody: '<p><b>RUMBU INDUSTRIES GROUP — Contract Department</b></p>' +
        '<p>' + escapeHtmlServer_(message).replace(/\n/g, '<br/>') + '</p>' +
        '<p style="color:#666;font-size:12px;">Sent by ' + escapeHtmlServer_(sender.name) + ' (' + escapeHtmlServer_(sender.email) + ') via the Contract Department platform, ' + fmtDate_(new Date()) + ' WAT.</p>'
    });
    updateRecord_('Escalations', row._row, { sentAt: nowIso_(), emailStatus: 'Sent' });
  } catch (e) {
    updateRecord_('Escalations', row._row, { emailStatus: 'Failed: ' + e.message });
  }

  logAudit_('direct_email_sent', 'escalations', toEmail, subject);
  invalidateCache_('escalations');
  return true;
}

function escapeHtmlServer_(s) {
  return String(s || '').replace(/[&<>"']/g, function (c) {
    return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
  });
}
