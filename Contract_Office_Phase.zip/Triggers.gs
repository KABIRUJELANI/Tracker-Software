/**
 * Triggers.gs
 * Installs the time-driven triggers that make escalation and compliance
 * checking automatic rather than something a human has to remember to run.
 * Call installTriggers() once from the "Rumbu Admin" spreadsheet menu (or the
 * Admin module in the web app) after SETUP.gs has run.
 */

function installTriggers() {
  removeExistingTriggers_();
  // Escalation scan: every 4 hours, catches stuck files/jobs/payments/KPIs quickly.
  ScriptApp.newTrigger('runEscalationScan_').timeBased().everyHours(4).create();
  // Daily-report compliance check: hourly in the afternoon/evening window; the
  // function itself no-ops before the configured cutoff hour (see DailyReports.gs).
  ScriptApp.newTrigger('runDailyComplianceCheck_').timeBased().everyHours(1).create();
  SpreadsheetApp.getActive().toast('Triggers installed: escalation scan (4h), compliance check (1h).', 'Rumbu Contract Dept', 6);
  return 'Triggers installed.';
}

function removeExistingTriggers_() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    if (t.getHandlerFunction() === 'runEscalationScan_' || t.getHandlerFunction() === 'runDailyComplianceCheck_') {
      ScriptApp.deleteTrigger(t);
    }
  });
}

/** Runs every module's own threshold scan. Each scan function decides for
 *  itself what "breach" means, using the configurable Settings thresholds. */
function runEscalationScan_() {
  runFilePositionalScan_();
  runJobsScan_();
  runPaymentsScan_();
  runKpiScan_();
}
